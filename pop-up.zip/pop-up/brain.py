import re
import random

class Brain:
    def __init__(self, intents):
        self.intents = intents

        def  get_response(self, user_message):
            user_message = user_message.lower()
            intent = self.get_intent(user_message)

            if intent:
                response = random.choice(intent["responses"])
            else:
                response = "sorry, i didn't  understand"
            return response
    
    def get_intent(self, user_message):
        for intent in self.intents:
            for pattern in intent["patterns"]:
                if re.search(pattern, user_message):
                    return intent
                
        return None